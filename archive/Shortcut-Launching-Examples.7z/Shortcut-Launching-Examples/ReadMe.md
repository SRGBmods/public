The following directories contain examples for launching applications after applying specific layouts & Effects in SignalRGB.

These examples will be retired when application auto detection is implemented.
(They can also be used by Elgato or Touch-Portal if need be.)

Several automation scripts now have automatic game / program exit detection.

If there is a Program or Game you would like an automation for please request it in Discord.